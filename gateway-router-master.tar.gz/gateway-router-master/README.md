# Gateway-router

Gateway-router är en generell API gateway komponent som primärt hantera tjänsteadresser. 
Den kan använda till många fler funktioner också...

För konfiguration möjlighet se dokumentationen för produkten
https://docs.spring.io/spring-cloud-gateway/reference/spring-cloud-gateway.html

Detta repo leder till en container som kan konfiguerar för olika subsystem och lösa routing där.
Containern kommer vilja läsa in en fil applikation.yml där routing, logging och diverse egenskaper för komponenten.

Exempel på routing:
```shell
spring:
  cloud:
    gateway:
      routes:
        - uri: ${referens.new.url}/referens/apisp/VerifieraLOA**/V1
          predicates:
            - Path=/referens/apisp/VerifieraLOA**/V1
          filters:
            - name: Retry
              args:
                retries: 1
                statuses: BAD_GATEWAY
                methods: GET,POST
                backoff:
                  firstBackoff: 10ms
                  maxBackoff: 50ms
                  factor: 2
                  basedOnPreviousValue: false
        - uri: ${referens.old.url}/referens/apisp/VerifieraRoll**/V1
          predicates:
            - Path=/referens/apisp/VerifieraRoll**/V1
          filters:
            - name: Retry
              args:
                retries: 1
                statuses: BAD_GATEWAY
                methods: GET,POST
                backoff:
                  firstBackoff: 10ms
                  maxBackoff: 50ms
                  factor: 2
                  basedOnPreviousValue: false
```
För  att starta, stoppa och bygga en container med podman kör
```shell
cd openshift/templates/local-podman-run
./maven-build.sh && ./binary-deploy.sh && ./run-build.sh
```



