#!/bin/bash

baseDir=$(cd $(dirname $0); pwd)
currentDir=$(pwd)

cd $baseDir > /dev/null
export GATEWAY_ROUTER=../../..
export OC_BUILD=target/oc-build

#### build image ####
rm -rf $OC_BUILD && mkdir -p $OC_BUILD/deployments && mkdir -p $OC_BUILD/configuration && mkdir -p $OC_BUILD/modules && mkdir -p $OC_BUILD/build-resources
cp ../../../target/*.*ar $OC_BUILD/deployments/
cp -R $GATEWAY_ROUTER/.s2i $OC_BUILD/

podman build -f Dockerfile.jvm -t gateway-router-v1