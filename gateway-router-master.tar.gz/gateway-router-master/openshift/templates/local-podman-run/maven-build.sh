#!/bin/bash

currentDir=$(pwd)

baseDir=$(cd $(dirname $0); pwd)
cd $baseDir > /dev/null

gitRepoBaseDir=../../..

######## MAIN ########

cd $gitRepoBaseDir > /dev/null

ls deployments > /dev/null 2>&1 && rm -r deployments

mvn \
  -DARTIFACT_DIR=gateway-router/target/ \
  --also-make \
  clean install \
  $@

cd $currentDir > /dev/null
