export OC_BUILD=../target/oc-build
currentDir=$(pwd)

podman run --rm \
-p 8081:8081 \
-p 8989:8989 \
--name gateway-router-v1 \
--env-file ./deploy-config.properties \
-v $currentDir/resource:/home/jboss/resource:Z \
--network mynetwork \
--ip 10.89.0.104 \
--privileged \
$@ \
gateway-router-v1
