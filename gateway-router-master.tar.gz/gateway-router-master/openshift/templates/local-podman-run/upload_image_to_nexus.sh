#!/bin/bash

baseDir=$(cd $(dirname $0); pwd)

serviceName=referens-v1
extImageName=referens

#imageServer=nexus-ehm-registry.systest.receptpartner.se
imageServer=nexus-ehm-registry.ehitd.ehalsomyndigheten.se
imageServerUser=docker
imageServerPassword=sk8foru


######## MAIN ########
test $# -eq 2 || { echo "usage: $(basename $0) sprint-name jira-issue"; exit 1; }

localImage=localhost/$serviceName
sprintName=$1
imageTagName=$2

podman tag $localImage:latest $imageServer/$sprintName/$extImageName:$imageTagName
podman login -u $imageServerUser -p $imageServerPassword $imageServer --tls-verify=false
#Pusha upp imagen som en docker-image
podman push -f v2s2 $imageServer/$sprintName/$extImageName:$imageTagName --tls-verify=false