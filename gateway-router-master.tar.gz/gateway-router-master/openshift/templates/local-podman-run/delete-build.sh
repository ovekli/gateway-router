#!/bin/bash
podman rmi -f gateway-router-v1
