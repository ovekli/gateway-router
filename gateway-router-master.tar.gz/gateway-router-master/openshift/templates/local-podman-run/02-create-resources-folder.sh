#!/bin/bash
#example ./02_create_resources-folder.sh https://test4.ehitd.ehalsomyndigheten.se:19443

export REFERENS_EAP=../../..

baseDir=$(cd $(dirname $0); pwd)
resourcesDir=$(cd $REFERENS_EAP/resource; pwd)
echo $resourcesDir

storeAddress=${1:-http://localhost:10080}

ecpProject=${2:-myproject}

cd $resourcesDir
pwd
ls -l ../referens-jboss/eap/config-templates
######## FUNC ########

######## MAIN ########
mkdir $baseDir/resource

for propertyFile in $(ls *.properties); do
	cp $propertyFile /tmp/$propertyFile
	sed -i "s/@STORE_ADDRESS@/$(echo $storeAddress | awk '{gsub(/\//,"\\/"); print $0}')/g" /tmp/$propertyFile
	sed -i "s/@ECP_PROJECT@/$(echo $ecpProject | awk '{gsub(/\//,"\\/"); print $0}')/g" /tmp/$propertyFile
	cp /tmp/$propertyFile $baseDir/resource
done

for jksFile in $(ls *.jks); do cp $resourcesDir/$jksFile $baseDir/resource; done
for xmlFile in $(ls *.xml); do cp $resourcesDir/$xmlFile $baseDir/resource; done
for yamlFile in $(ls *.y*ml); do cp $resourcesDir/$yamlFile $baseDir/resource; done
cp $resourcesDir/ehmcacerts $baseDir/resource

cd - > /dev/null
